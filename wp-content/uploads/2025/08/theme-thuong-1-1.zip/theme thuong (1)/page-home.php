<?php get_header(); ?>
<section class="appilix_hero appilix_section_space_hero">
    <div class="appilix_container">

        <div class="notification_slide">
            <div class="hero_notification google" onclick="window.open('https://www.google.com/maps/place/Appilix/@23.7752302,90.3519427,17z/data=!4m18!1m9!3m8!1s0x23e0164bf41c099b:0x99f61c3aa9b9afcf!2sAppilix!8m2!3d23.7752302!4d90.3519427!9m1!1b1!16s%2Fg%2F11v0_clmrq!3m7!1s0x23e0164bf41c099b:0x99f61c3aa9b9afcf!8m2!3d23.7752302!4d90.3519427!9m1!1b1!16s%2Fg%2F11v0_clmrq', '_blank')">
                <div class="user_icon">
                </div>
                <div class="notification"><b>4.3</b>
                    <span></span>
                    <b>Google</b> Reviews</div>
            </div>
            <div class="hero_notification trustpilot" onclick="window.open('https://www.trustpilot.com/review/appilix.com', '_blank')">
                <div class="user_icon">
                </div>
                <div class="notification"><b>4.8</b>
                    <span></span>
                    <b>Trustpilot</b> Reviews</div>
            </div>
            <div class="hero_notification users">
                <div class="user_icon">
                </div>
                <div class="notification"><b>120k+</b>Users have Created Apps via <b>Appilix</b></div>
            </div>
        </div>

        <div data-aos="fade-up" class="appilix_section_header">
            <h1>Convert Your Website to a Mobile App Without Any Coding</h1>
            <p>Appilix is the ultimate solution for converting your website into a mobile app. Get started today and take your web presence to the next level!</p>
        </div>

        <form data-aos="zoom-in" data-aos-delay="300" class="create_form" action="https://appilix.com/account/new-app" onsubmit="addHttpIfMissing()">
            <div class="input_block">
                <input type="text" name="website" id="websiteInput" autocomplete="off" spellcheck="false" required="">
                <span class="placeholder">Enter your Website Address</span>
            </div>
            <button class="create_btn" type="submit" href="#">Convert to App<span class="arrow_right"></span></button>
        </form>

        <div data-aos="fade-up" data-aos-delay="300" class="hero_features">
            <div class="hf_card">
                <div class="icon icon_1"></div>
                <div class="details">
                    Firebase Push Notification
                </div>
            </div>
            <div class="hf_card">
                <div class="icon icon_2"></div>
                <div class="details">
                    Admob Ad Integration
                </div>
            </div>
            <div class="hf_card">
                <div class="icon icon_3"></div>
                <div class="details">
                    Biometric Authentication
                </div>
            </div>
            <div class="hf_card">
                <div class="icon icon_4"></div>
                <div class="details">
                    Navigation Drawer Menu
                </div>
            </div>
            <div class="hf_card">
                <div class="icon icon_5"></div>
                <div class="details">
                    Deep Link Integration
                </div>
            </div>
            <div class="hf_card">
                <div class="icon icon_6"></div>
                <div class="details">
                    Customizable Splash Screen
                </div>
            </div>
        </div>

    </div>
</section>


<section class="appilix_3_steps appilix_section_space_large">
    <div class="appilix_container">
        <div class="steps_elements">
            <div class="details">
                <div data-aos="fade-up" class="appilix_section_header">
                    <h2 class="left_then_center">03 Steps to Convert your <span>Website to App</span></h2>
                    <p class="left_then_center">Seamlessly convert your web presence into an Android or iOS mobile app in just 3 steps. No coding knowledge, build in minutes.</p>
                </div>
                <div data-aos="fade-up" data-aos-delay="100" class="three_cards">
                    <div class="card">
                        <div class="icon"></div>
                        <div class="card_details">
                            <h3>1. Enter Website URL</h3>
                            <p>Enter your web address, give a name of your app and convert the website to app for Android or iOS device.</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="icon"></div>
                        <div class="card_details">
                            <h3>2. Customize the App</h3>
                            <p>Personalize the app with custom logo, stunning splash screens and advanced features. Easy and hassle-free!</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="icon"></div>
                        <div class="card_details">
                            <h3>3. Build & Download</h3>
                            <p>Appilix's website to mobile app conversion process builds your Android or iOS app in less than 5 minutes!</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section_img">
                <a class="play_btn popup-youtube" aria-label="Watch how Appilix Converts your Web to APK" href="https://www.youtube.com/watch?v=MV7lh9Qh5gM?rel=0&ytp-pause-overlay=0"></a>
                <img loading="lazy" src="images/rJ2ak0jYjkJg.webp" alt="Play Video">
            </div>
        </div>
    </div>
</section>



<section class="appilix_features_1 appilix_section_space_large_to_medium">
    <div class="appilix_container">
        <div data-aos="fade-up" class="appilix_section_header">
            <span class="top_title">Native Integration Modules</span>
            <h2>Top Features of Appilix Website to App Builder</h2>
            <p>Explore Appilix's Website to App Builder with advanced tools to easily convert your website into a fully functional mobile app.</p>
        </div>
        <div data-aos="fade-up" data-aos-delay="100" class="features_integrator_cards">
            <div class="card">
                <div class="icon">
                    <img src="images/8WTXTBTDaMjd.svg" alt="Firebase Push Notification">
                </div>
                <div class="text">
                    <h3>Firebase Push Notification</h3>
                    <p>Integrate Firebase to send Push Notification to all app users directly from the Appilix Control Panel.</p>
                </div>
            </div>
            <div class="card">
                <div class="icon">
                    <img src="images/S9ey1AURYpSz.svg" alt="Admob Ads">
                </div>
                <div class="text">
                    <h3>Admob Ads</h3>
                    <p>Integrate Admob to display ads and boost revenue, unlocking full monetization potential for your website to app solution.</p>
                </div>
            </div>
            <div class="card">
                <div class="icon">
                    <img src="images/iEvLnOoaoJ4o.svg" alt="Navigation Drawer">
                </div>
                <div class="text">
                    <h3>Navigation Drawer</h3>
                    <p>Add a navigation drawer for easy access, enhancing your website to mobile app experience with a real app-like interface.</p>
                </div>
            </div>
            <div class="card">
                <div class="icon">
                    <img src="images/ITJLVYvJwelt.svg" alt="Bottom Navigation">
                </div>
                <div class="text">
                    <h3>Bottom Navigation</h3>
                    <p>Display quick navigation menu on the bottom of the app to provide easy and seamless user experience.</p>
                </div>
            </div>
            <div class="card">
                <div class="icon">
                    <img src="images/sXRNl1irzlys.svg" alt="Splash Screen">
                </div>
                <div class="text">
                    <h3>Splash Screen</h3>
                    <p>Set an initial screen with custom logo and background that appears when the application is launched.</p>
                </div>
            </div>
            <div class="card">
                <div class="icon">
                    <img src="images/BXHFcD2CL4uW.svg" alt="Deep Link">
                </div>
                <div class="text">
                    <h3>Deep Link</h3>
                    <p>Automatically open the app when your website is being browsed or the website URL being clicked on other apps.</p>
                </div>
            </div>
            <div class="card">
                <div class="icon">
                    <img src="images/BHj8q9ZFGHoG.svg" alt="Custom CSS & JS">
                </div>
                <div class="text">
                    <h3>Custom CSS & JS</h3>
                    <p>Add custom CSS or Javascript codes to customize the website to app experience with extra features.</p>
                </div>
            </div>
            <div class="card">
                <div class="icon">
                    <img src="images/Mkey3ihsV6GW.svg" alt="Native Google Sign-in">
                </div>
                <div class="text">
                    <h3>Native Google Sign-in</h3>
                    <p>Enable Google sign-in for native authentication, making it easier for users to access your website in mobile app securely.</p>
                </div>
            </div>
            <div class="card">
                <div class="icon">
                    <img src="images/569kU0DwbSW8.svg" alt="Biometric Authentication">
                </div>
                <div class="text">
                    <h3>Biometric Authentication</h3>
                    <p>Enhance your security for the entire app or specific part of your app with biometric authentication system.</p>
                </div>
            </div>
        </div>
        <div class="important_note">
            <p>There are more exciting features and native modules of Appilix. <a href="https://appilix.com/features" class="with_arrow">Explore All Features</a></p>
        </div>
    </div>
</section>



<section class="appilix_details_1 appilix_section_space_large">
    <div class="appilix_container">
        <div data-aos="fade-up" class="appilix_section_header">
            <h2>Unlock the Benefits of Web to App Converter</h2>
            <p>Experience the seamless transition from website to mobile app with Appilix, unlocking a world of benefits including enhanced user engagement.</p>
        </div>
        <div data-aos="fade-up" data-aos-delay="100" class="details_elements">
            <div class="details_img">
                <img loading="lazy" src="images/rJ2ak0jYjkJg.webp" alt="Appilix Mockup">
            </div>
            <div class="details_text">
                <span class="point">Transform, Engage, Thrive</span>
                <p>Converting your website to a mobile app is now quick and easy with Appilix's web to app converter. Appilix ensures a seamless experience, providing a native look and feel for both Android and iOS apps, so users enjoy a smooth, intuitive interface.</p>

                <p>With mobile users spending about 90% of their time in apps, according to eMarketer, converting your website to app offers a direct way to engage your audience. This leads to greater visibility and interaction with your products or services, expanding your reach and enhancing the overall user experience.</p>
                <ul class="key_points">
                    <li>Seamless Transition from Web to App</li>
                    <li>Boost User Engagement</li>
                    <li>Increased Visibility and Reach</li>
                    <li>Enhanced User Experience</li>
                </ul>
                <a class="get_start_btn" href="https://appilix.com/account/new-app"> Get Started Now</a>
            </div>
        </div>
    </div>
</section>


<section class="appilix_cta_1">
    <div class="appilix_container">
        <div class="appilix_section_header">
            <h2>Transform Your Website into a Mobile App!</h2>
            <p>Ready to bring your website to life on Android and iOS? With Appilix, converting your website to an Android and iOS app is easier—no coding required! Start now and elevate your business on both mobile platforms.</p>
            <a href="https://appilix.com/account/new-app">Get Started Now</a>
        </div>
    </div>
</section>


<section class="appilix_builder_highlight appilix_section_space_large">
    <div class="appilix_container">
        <div data-aos="fade-up" class="appilix_section_header">
            <span class="top_title">Powerful App Builder</span>
            <h2>Build Your Mobile App in Just 5 Minutes!</h2>
            <p>Create and customize your website into an app in 5 minutes! No coding required—access the builder from any device and personalize every detail.</p>
        </div>
        <div data-aos="fade-up" data-aos-delay="100" class="highlighted_contents">
            <div class="sec_img">
                <img loading="lazy" src="images/AniV0KTDBzzU.png" alt="Appilix App Builder">
            </div>
            <div class="highlighted_card_container">
                <div class="features_cards">
                    <div class="card card_1">
                        <div class="icon i_1"></div>
                        <div class="text">
                            <h3>Fast Web to App Conversion</h3>
                            <p>Convert your website into a mobile app in just 5 minutes. Enjoy a hassle-free experience with our fast, browser-based web to mobile app builder.</p>
                        </div>
                    </div>
                    <div class="card card_2">
                        <div class="icon i_2"></div>
                        <div class="text">
                            <h3>Fully Customizable Features</h3>
                            <p>Personalize every aspect of your web to app, including splash screens, navigation, and colors, all without writing a single line of code.</p>
                        </div>
                    </div>
                    <div class="card card_3">
                        <div class="icon i_3"></div>
                        <div class="text">
                            <h3>Access from Anywhere</h3>
                            <p>No need for Mac or Windows PC! Build and customize your website to app directly from your browser on any device, anytime.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<hr class="appilix_divider">


<!--Appilix Landing Pricing Section-->
<section class="appilix_pricing_section appilix_section_space_large">
    <div class="appilix_container">
        <div data-aos="fade-up" class="appilix_section_header">
            <h2>Transparent Pricing for Android & iOS Apps</h2>
            <p>Choose the plan that fits your needs—no hidden charges. Get all future updates, whether you’re converting your website to app or updating one!</p>
        </div>
        <div data-aos="fade-up" data-aos-delay="100" class="tab">
            <span class="item android active">Android</span>
            <span class="item ios">iOS</span>
        </div>
        <div data-aos="fade-up" data-aos-delay="100" class="price_cards_container">
            <div class="price_cards">
                <div class="p_card">
                    <h3 class="card_head">Free</h3>
                    <h3 class="price">$0.00</h3>
                    <p>Let's build your first app for free and explore for 30 days.</p>
                    <a href="https://appilix.com/account/new-app" class="card_btn">Get Started Now</a>
                    <ul class="features_list">
                        <li class="checked"><b>1 Android</b> Application</li>
                        <li class="checked"><b>Unlimited</b> Builds</li>
                        <li class="checked"><b>Unlimited</b> Active Users</li>
                        <li class="unchecked">Play Store Releasable</li>
                        <li class="unchecked">No Appilix Logo</li>
                        <li class="unchecked">Admob Ad</li>
                        <li class="unchecked">Push Notifications</li>
                        <li class="unchecked">All <a href="https://appilix.com/features#integration-modules">Integration Modules</a></li>
                    </ul>
                </div>
                <div class="p_card p_card_highlight">
                    <h3 class="card_head">Lifetime</h3>
                                            <h3 class="price">$89.00</h3>
                                        <p>All premium features and no need to worry about renewal.</p>
                    <a href="https://appilix.com/account/new-app" class="card_btn">Get Started Now</a>
                    <ul class="features_list">
                        <li class="checked"><b>1 Android</b> Application</li>
                        <li class="checked"><b>Unlimited</b> Builds</li>
                        <li class="checked"><b>Unlimited</b> Active Users</li>
                        <li class="checked">Play Store Releasable</li>
                        <li class="checked">No Appilix Logo</li>
                        <li class="checked">Admob Ad</li>
                        <li class="checked">Push Notifications</li>
                        <li class="checked">All <a href="https://appilix.com/features#integration-modules">Integration Modules</a></li>
                    </ul>
                </div>
                <div class="p_card ">
                    <h3 class="card_head">Yearly</h3>
                                            <h3 class="price">$69.00</h3>
                                        <p>Billed as $$69.00 per year including all the features and updates.</p>
                    <a href="https://appilix.com/account/new-app" class="card_btn">Get Started Now</a>
                    <ul class="features_list">
                        <li class="checked"><b>1 Android</b> Application</li>
                        <li class="checked"><b>Unlimited</b> Builds</li>
                        <li class="checked"><b>Unlimited</b> Active Users</li>
                        <li class="checked">Play Store Releasable</li>
                        <li class="checked">No Appilix Logo</li>
                        <li class="checked">Admob Ad</li>
                        <li class="checked">Push Notifications</li>
                        <li class="checked">All <a href="https://appilix.com/features#integration-modules">Integration Modules</a></li>
                    </ul>
                </div>
            </div>
            <div class="price_cards">
                <div class="p_card">
                    <h3 class="card_head">Free</h3>
                    <h3 class="price">$0.00</h3>

                    <p>Let's build your first app for free and explore for 30 days.</p>
                    <a href="https://appilix.com/account/new-app" class="card_btn">Get Started Now</a>
                    <ul class="features_list">
                        <li class="checked"><b>1 iOS</b> Application</li>
                        <li class="checked"><b>Unlimited</b> Builds</li>
                        <li class="checked"><b>Unlimited</b> Active Users</li>
                        <li class="unchecked">Apple Store Releasable</li>
                        <li class="unchecked">No Appilix Logo</li>
                        <li class="unchecked">Admob Ad</li>
                        <li class="unchecked">Push Notifications</li>
                        <li class="unchecked">All <a href="https://appilix.com/features#integration-modules">Integration Modules</a></li>
                    </ul>
                </div>
                <div class="p_card p_card_highlight">
                    <h3 class="card_head">Lifetime</h3>
                                            <h3 class="price">$139.00</h3>
                                        <p>All premium features and no need to worry about renewal.</p>
                    <a href="https://appilix.com/account/new-app" class="card_btn">Get Started Now</a>
                    <ul class="features_list">
                        <li class="checked"><b>1 iOS</b> Application</li>
                        <li class="checked"><b>Unlimited</b> Builds</li>
                        <li class="checked"><b>Unlimited</b> Active Users</li>
                        <li class="checked">Apple Store Releasable</li>
                        <li class="checked">No Appilix Logo</li>
                        <li class="checked">Admob Ad</li>
                        <li class="checked">Push Notifications</li>
                        <li class="checked">All <a href="https://appilix.com/features#integration-modules">Integration Modules</a></li>
                    </ul>
                </div>
                <div class="p_card ">
                    <h3 class="card_head">Yearly</h3>
                                            <h3 class="price">$79.00</h3>
                                        <p>Billed as $79.00 per year including all the features and updates.</p>
                    <a href="https://appilix.com/account/new-app" class="card_btn">Get Started Now</a>
                    <ul class="features_list">
                        <li class="checked"><b>1 iOS</b> Application</li>
                        <li class="checked"><b>Unlimited</b> Builds</li>
                        <li class="checked"><b>Unlimited</b> Active Users</li>
                        <li class="checked">Apple Store Releasable</li>
                        <li class="checked">No Appilix Logo</li>
                        <li class="checked">Admob Ad</li>
                        <li class="checked">Push Notifications</li>
                        <li class="checked">All <a href="https://appilix.com/features#integration-modules">Integration Modules</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="important_note">
            <p>The above prices do not include applicable taxes based on your billing address. The final price will be displayed on the checkout section, before the payment is completed.</p>
        </div>
    </div>
</section>

<hr class="appilix_divider">

<!--Appilix Review of User-->
<section class="appilix_statement appilix_section_space_large">
    <div class="appilix_container">
        <div class="content">
            <div class="profile">
                <div class="arrow"></div>
                <img loading="lazy" src="images/96HYRrtcGJWI.webp" alt="Ferdousur Rahman Sarker">
            </div>
            <div class="details">
                <p>At Appilix, we’re dedicated to continuous improvement, adding new features and enhancing <span>customer support</span> to ensure your success with every app build.</p>
                <div class="intro">
                    <span class="person_name">Ferdousur Rahman Sarker</span>
                    <span class="person_designation">CEO, Appilix</span>
                </div>
            </div>
        </div>
        <!--<div class="user_companies">
            <img src="https://appilix.com/styles/images/theme/appilix_company_logo_1.svg" alt="">
            <img src="https://appilix.com/styles/images/theme/appilix_company_logo_1.svg" alt="">
            <img src="https://appilix.com/styles/images/theme/appilix_company_logo_1.svg" alt="">
            <img src="https://appilix.com/styles/images/theme/appilix_company_logo_1.svg" alt="">
            <img src="https://appilix.com/styles/images/theme/appilix_company_logo_1.svg" alt="">
            <img src="https://appilix.com/styles/images/theme/appilix_company_logo_1.svg" alt="">
        </div>-->
    </div>
</section>

<hr class="appilix_divider">

<!--Appilix Review Section-->
<section id="appilix_review" class="appilix_review appilix_section_space_large">
    <div class="appilix_container">
        <div class="appilix_section_header">
            <h2 class="left_then_center">What Clients Say About Our Exceptional Service</h2>
            <div class="slider">
                <div class="slide s_left"></div>
                <div class="slide s_right"></div>
            </div>

        </div>
        <div class="review_cards">
            <div class="card">
                <p><a class="review_link" href="https://www.trustpilot.com/reviews/679b65f41de847d6b2d9b932" aria-label="Check the review on TrustPilot about Appilix" rel="nofollow" target="_blank"></a> Appilix is the best software I've found quality price is the cheapest one and they offer the lifetime plan, go for it. They also helped me to publish the app on apple store, I am happy I found appilix.com, thank you so much.</p>
                <div class="card_bottom">
                    <div class="reviewer">
                        <h3>Khaled Mahieddine</h3>
                        <span>United States</span>
                    </div>
                    <div class="reviewer_dp">
                        <img src="images/bQ10uRqX1Urv.svg" alt="Khaled Mahieddine">
                    </div>
                </div>
            </div>
            <div class="card">
                <p><a class="review_link" href="https://www.trustpilot.com/reviews/66110f1427893d03460c477b" aria-label="Check the review on TrustPilot about Appilix" rel="nofollow" target="_blank"></a> I am super impressed with appilix. They have easy step by step videos to follow all less than a couple of minutes. I already had a website and ats portal that was only accessible online. I have now been able to have my ats as an app all through supplying my website link. If you already have a website then you’re more than half way there. Reached out to customer service twice and they came back to me super quickly, within hours and both times was able to resolve my query.</p>
                <div class="card_bottom">
                    <div class="reviewer">
                        <h3>Fiona</h3>
                        <span>United Kingdom</span>
                    </div>
                    <div class="reviewer_dp">
                        <img src="images/bQ10uRqX1Urv.svg" alt="Fiona">
                    </div>
                </div>
            </div>
            <div class="card ">
                <p><a class="review_link" href="https://www.trustpilot.com/reviews/6550aeec908f5b6b46a10619" aria-label="Check the review on TrustPilot about Appilix" rel="nofollow" target="_blank"></a> Appilix is a very good website to App conversion software. Appilix creates a beautiful and attractive App with a variety of features. I have been able to create an Android and iOS App in a few seconds and also the customer service is very good as they have been side by side with me to solve all the problems that arose during the submission to the Play Store and App Store. Thank you very much Appilix for the great service you are the best company and role model.</p>
                <div class="card_bottom">
                    <div class="reviewer">
                        <h3>Winox Com</h3>
                        <span>Tanzania</span>
                    </div>
                    <div class="reviewer_dp">
                        <img src="images/bQ10uRqX1Urv.svg" alt="Winox Com">
                    </div>
                </div>
            </div>
            <div class="card">
                <p><a class="review_link" href="https://www.trustpilot.com/reviews/6719103432b314637cb110ad" aria-label="Check the review on TrustPilot about Appilix" rel="nofollow" target="_blank"></a> The Appilix team is very enthusiastic. I am not good at English when communicating with the support department, so it is a bit difficult to exchange support. The Appilix support team was very enthusiastic in helping to successfully launch my app on Apple. Thank you all very much. Wishing you all success.</p>
                <div class="card_bottom">
                    <div class="reviewer">
                        <h3>Văn Thanh Tống</h3>
                        <span>Vietnam</span>
                    </div>
                    <div class="reviewer_dp">
                        <img src="images/bQ10uRqX1Urv.svg" alt="Văn Thanh Tống">
                    </div>
                </div>
            </div>
            <div class="card">
                <p><a class="review_link" href="https://www.trustpilot.com/reviews/6717bd8b68258c863b81c407" aria-label="Check the review on TrustPilot about Appilix" rel="nofollow" target="_blank"></a> Appilix is the best service I have tested to transform a website into an APP. Very valid for both the Apple and Android platforms. The process of creating and publishing the APP is very simple and explained very well by the guide, but if a small problem occurs, Appilix assistance intervenes immediately to help. Really fantastic! I am really happy I chose this service.</p>
                <div class="card_bottom">
                    <div class="reviewer">
                        <h3>Lele</h3>
                        <span>Italy</span>
                    </div>
                    <div class="reviewer_dp">
                        <img src="images/bQ10uRqX1Urv.svg" alt="Lele">
                    </div>
                </div>
            </div>
        </div>


        <div class="statistics">
            <div class="sts st_1">
                <h3>80k+</h3>
                <p>Users have already created Android & iOS Apps using Appilix</p>
            </div>
            <div class="sts st_2">
                <h3>✰✰✰✰✰</h3>
                <p>4.5+ Overall Rating from our users received on different channels</p>
            </div>
            <div class="sts st_3">
                <h3>24hrs</h3>
                <p>Customer Support in assistance with web to app conversion</p>
            </div>
        </div>
    </div>
</section>




<div class="appilix_sales_notification" onclick="window.location.href='https://appilix.com/pricing';">
    <span class="user_icon"></span>
    <div class="sale_details">
        <h4><span class="user_name">Ferdousur</span> from <span class="user_location">Dhaka, Bangladesh</span></h4>
        <h5>Just Purchased <span class="plan_title">Android Lifetime</span> Plan</h5>
        <h6>9 hours ago</h6>
    </div>
</div>


<!--Appilix Subscription for News and Updates-->
<section class="appilix_newsletter appilix_section_space_medium">
    <div class="appilix_container">
        <div class="flex_container">
            <div class="appilix_section_header">
                <h2 class="left_then_center">Stay up to date with our news, ideas and updates</h2>
            </div>
            <div class="newsletter_form">
                <input type="email" autocomplete="off" class="email_input email" placeholder="Your email address" onkeyup="field_remove_errors(this)">
                <button type="submit" class="btn" onclick="email_subscription(`https://appilix.com`, `.appilix_newsletter button.btn`, `.appilix_newsletter input.email`)">Subscribe Now</button>
            </div>
        </div>
    </div>
</section>

<!--Appilix Section Divider-->
<section class="appilix_sec_divider">
    <hr class="appilix_divider">
</section>
<?php get_footer(); ?>